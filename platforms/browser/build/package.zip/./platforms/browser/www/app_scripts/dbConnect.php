<?php

$DB_HOST = "mysql.hostinger.in";
$DB_USER = "u281959195_of";
$DB_PASS = "123456";
$DB_NAME = "u281959195_of";

?>